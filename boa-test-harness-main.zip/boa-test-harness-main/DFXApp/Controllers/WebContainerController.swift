//
//  WebContainerController.swift
//  DFXApp
//
//  Created by Shobhit Agrawal on 30/08/22.
//

import UIKit

class WebContainerController: UIViewController {
    
    //MARK: Constants & Variables
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var tryAgainView: UIView!
    @IBOutlet weak var tryAgainButton: UIButton!
    
    var willWebViewOpen : Bool = true
    
    //MARK: View Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        self.navigateToWebView()
    }
    
    //MARK: Private Methods
    private func navigateToWebView() {
        if self.willWebViewOpen {
            self.willWebViewOpen = false
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "WebViewController")
            vc.modalPresentationStyle = .fullScreen
            
            self.present(vc, animated: true, completion: nil)
        }
    }
    
    //MARK: IBAction Methods
    @IBAction func tryAgainAction(_ sender: Any) {
        self.willWebViewOpen = true
        self.navigateToWebView()
    }
    
}
