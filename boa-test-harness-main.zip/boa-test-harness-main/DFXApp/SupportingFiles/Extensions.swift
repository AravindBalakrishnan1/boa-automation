//
//  Extensions.swift
//  DFXApp
//
//  Created by Shobhit Agrawal on 08/09/22.
//

import Foundation
import UIKit

extension UIViewController {
    
    func showAlert(message: String) {
        
        let alert = UIAlertController(title: Constants.ProjectName, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}
