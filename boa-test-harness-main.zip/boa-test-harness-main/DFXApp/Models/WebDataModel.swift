//
//  WebDataModel.swift
//  DFXApp
//
//  Created by Shobhit Agrawal on 30/08/22.
//

import Foundation

struct WebDataModel {
    
}
