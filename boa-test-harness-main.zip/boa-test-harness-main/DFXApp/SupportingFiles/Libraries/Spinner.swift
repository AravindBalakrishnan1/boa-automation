//
//  Spinner.swift
//  DFXApp
//
//  Created by Shobhit Agrawal on 06/09/22.
//

import Foundation
import UIKit

class Spinner {
    
    static var blurView = UIView()
    
    private static var loader: UIActivityIndicatorView = {
        let indicator = UIActivityIndicatorView(style: .large)
        indicator.frame = blurView.frame
        indicator.color = .white
        indicator.center = blurView.center
        indicator.translatesAutoresizingMaskIntoConstraints = false
        indicator.startAnimating()
        return indicator
    }()
    
    static func showLoader(controller: UIViewController) {
        loader.startAnimating()
        blurView.backgroundColor = UIColor(white: 0, alpha: 0.4)
        blurView.frame = controller.view.frame
        blurView.addSubview(loader)
        loader.centerXAnchor.constraint(equalTo: blurView.centerXAnchor).isActive = true
        loader.centerYAnchor.constraint(equalTo: blurView.centerYAnchor).isActive = true
        controller.view.addSubview(blurView)
    }
    
    static func hideLoader(){
        loader.stopAnimating()
        blurView.removeFromSuperview()
    }
}

