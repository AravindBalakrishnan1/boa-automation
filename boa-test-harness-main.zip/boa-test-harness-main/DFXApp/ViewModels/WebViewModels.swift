//
//  WebViewModels.swift
//  DFXApp
//
//  Created by Shobhit Agrawal on 30/08/22.
//

import Foundation

class WebViewModel {
    
    var baseURL: String {
        return Configuration.environment.baseURL
    }
    
    var isDevelopmentEnv: Bool {
        return Configuration.environment != .production
    }
    
    init() {
        
    }
    
}
