//
//  WebViewController.swift
//  DFXApp
//
//  Created by Shobhit Agrawal on 18/10/22.
//

import Foundation
import WebKit

class WebViewController: UIViewController, WKUIDelegate {
    
    @IBOutlet weak var parentWebView: UIView!
    @IBOutlet weak var closeButton: UIButton!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var forwardButton: UIButton!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
        
    lazy var webView : WKWebView = {
        let wvView = WKWebView(frame: self.parentWebView.bounds, configuration: getConfiguration())
        wvView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        wvView.navigationDelegate = self
        wvView.uiDelegate = self
        wvView.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 16_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148"
        return wvView
    }()
    
    var viewModel: WebViewModel = WebViewModel()
    
    //MARK: View Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.loadWebView()
    }
    
    func loadWebView() {
                
        guard let url = URL(string: viewModel.baseURL) else {
            return
        }
        self.parentWebView.addSubview(webView)
        webView.load(URLRequest(url: url))
        print("URL \(url)")
    }
    
    //Advance configuration of web view
    private func getConfiguration() -> WKWebViewConfiguration {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = WKWebsiteDataStore.nonPersistent()
        configuration.dataDetectorTypes = .phoneNumber
        configuration.userContentController.add(self, name: "openDocument")
        
        if viewModel.isDevelopmentEnv {
            configuration.preferences.setValue(true, forKey: "developerExtrasEnabled")
        }
        
        return configuration
    }
    
    func updateToolBar() {
        self.backButton.isEnabled = self.webView.canGoBack
        self.forwardButton.isEnabled = self.webView.canGoForward
    }
    
}

//MARK: - IBActions
extension WebViewController {
    @IBAction func closeWebViewAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func backAction(_ sender: Any) {
        webView.goBack()
    }
    
    @IBAction func forwardAction(_ sender: Any) {
        webView.goForward()
    }
}

//MARK: - Ext: WKNavigationDelegate
extension WebViewController: WKNavigationDelegate {
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        print("Started to load Web View")
        activityIndicator.startAnimating()
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        print("Finished loading Web View")
        activityIndicator.stopAnimating()
        self.updateToolBar()
    }
    
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        print(error.localizedDescription)
        activityIndicator.stopAnimating()
        self.updateToolBar()
    }
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        
        if navigationAction.request.url?.scheme == "tel" {//For handle phone number tap
            UIApplication.shared.open(navigationAction.request.url!)
            decisionHandler(.cancel)
            
        }else if let url = navigationAction.request.url, (url.absoluteString.contains("download") || url.absoluteString.contains(".pdf") || url.absoluteString.contains("/handlers/")){
            executeDocumentDownloadScript(forAbsoluteUrl: url.absoluteString)
            if #available(iOS 14.5, *) {
                decisionHandler(.download)
            } else {
                decisionHandler(.allow)
            }

        } else {
            decisionHandler(.allow)
        }
    }

    private func executeDocumentDownloadScript(forAbsoluteUrl absoluteUrl : String) {
            // TODO: Add more supported mime-types for missing content-disposition headers
            webView.evaluateJavaScript("""
                (async function download() {
                    const url = '\(absoluteUrl)';
                    try {
                        // we use a second try block here to have more detailed error information
                        // because of the nature of JS the outer try-catch doesn't know anything where the error happended
                        let res;
                        try {
                            res = await fetch(url, {
                                credentials: 'include'
                            });
                        } catch (err) {
                            window.webkit.messageHandlers.jsError.postMessage(`fetch threw, error: ${err}, url: ${url}`);
                            return;
                        }
                        if (!res.ok) {
                            window.webkit.messageHandlers.jsError.postMessage(`Response status was not ok, status: ${res.status}, url: ${url}`);
                            return;
                        }
                        const contentDisp = res.headers.get('content-disposition');
                        if (contentDisp) {
                            const match = contentDisp.match(/(^;|)\\s*filename=\\s*(\"([^\"]*)\"|([^;\\s]*))\\s*(;|$)/i);
                            if (match) {
                                filename = match[3] || match[4];
                            }
                        } else{
                                if(url.includes(".pdf")){
                                       
                                        filename = url.substring(url.lastIndexOf('/')+1);
                                        console.log(filename);
                                }
                        }
                        if (!filename) {
                            const contentType = res.headers.get('content-type');
                            if (contentType) {
                                if (contentType.indexOf('application/json') === 0) {
                                    filename = 'unnamed.pdf';
                                } else if (contentType.indexOf('image/tiff') === 0) {
                                    filename = 'unnamed.tiff';
                                }
                            }
                        }
                        if (!filename) {
                            window.webkit.messageHandlers.jsError.postMessage(`Could not determine filename from content-disposition nor content-type, content-dispositon: ${contentDispositon}, content-type: ${contentType}, url: ${url}`);
                        }
                        let data;
                        try {
                            data = await res.blob();
                        } catch (err) {
                            window.webkit.messageHandlers.jsError.postMessage(`res.blob() threw, error: ${err}, url: ${url}`);
                            return;
                        }
                        const fr = new FileReader();
                        fr.onload = () => {
                            window.webkit.messageHandlers.openDocument.postMessage(`${filename};${fr.result}`)
                        };
                        fr.addEventListener('error', (err) => {
                            window.webkit.messageHandlers.jsError.postMessage(`FileReader threw, error: ${err}`)
                        })
                        fr.readAsDataURL(data);
                    } catch (err) {
                        // TODO: better log the error, currently only TypeError: Type error
                        window.webkit.messageHandlers.jsError.postMessage(`JSError while downloading document, url: ${url}, err: ${err}`)
                    }
                })();
                // null is needed here as this eval returns the last statement and we can't return a promise
                null;
            """) { (result, err) in
                if (err != nil) {
                    debugPrint("JS ERR: \(String(describing: err))")
                }
            }
        }
}
extension WebViewController: WKScriptMessageHandler {
    
    public func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
     
           if (message.name == "openDocument") {
               handleDocument(messageBody: message.body as! String)
           } else if (message.name == "jsError") {
               debugPrint(message.body as! String)
           }
       }
    
    private func handleDocument(messageBody: String) {
            // messageBody is in the format ;data:;base64,
              
            // split on the first ";", to reveal the filename
            let filenameSplits = messageBody.split(separator: ";", maxSplits: 1, omittingEmptySubsequences: false)
              
            let filename = String(filenameSplits[0])
              
            // split the remaining part on the first ",", to reveal the base64 data
            let dataSplits = filenameSplits[1].split(separator: ",", maxSplits: 1, omittingEmptySubsequences: false)
              
            let data = Data(base64Encoded: String(dataSplits[1]))
              
            if (data == nil) {
                debugPrint("Could not construct data from base64")
                return
            }
              
            // store the file on disk (.removingPercentEncoding removes possible URL encoded characters like "%20" for blank)
            let localFileURL = FileManager.default.temporaryDirectory.appendingPathComponent(filename.removingPercentEncoding ?? filename)
              
            do {
                activityIndicator.startAnimating()
                try data!.write(to: localFileURL);
            } catch {
                activityIndicator.stopAnimating()
                debugPrint(error)
                return
            }
              
            // and display it in QL
            DispatchQueue.main.async {
                self.activityIndicator.stopAnimating()
                var documentInteractionController: UIDocumentInteractionController!
                documentInteractionController = UIDocumentInteractionController.init(url: localFileURL)
                documentInteractionController?.delegate = self
                documentInteractionController?.presentPreview(animated: true)
            }
        }
}
extension WebViewController: UIDocumentInteractionControllerDelegate {
    func documentInteractionControllerViewControllerForPreview(_ controller: UIDocumentInteractionController) -> UIViewController {
        return self
    }
}
