//
//  Configuration.swift
//  DFXApp
//
//  Created by Shobhit Agrawal on 05/09/22.
//

import Foundation
import UIKit

enum Environment {
    
    case development
    case staging
    case production
    
    var baseURL : String {
        switch self {
        case .development:
            return "https://test2.reninc.com/"
            
        case .staging:
            return "https://boa-uat.donorfirstx.com/"
            
        case .production:
            return "https://bofa.donorfirst.org/"
        }
    }
}

struct Configuration {
    
    static var environment: Environment = {
        
        if let configuration = Bundle.main.object(forInfoDictionaryKey: Constants.Configuration) as? String {
            if configuration.range(of: Constants.Development) != nil{
                return Environment.development
                
            }else if configuration.range(of: Constants.Staging) != nil{
                return Environment.staging
                
            }else if configuration.range(of: Constants.Production) != nil {
                return Environment.production
            }
        }
        return Environment.development
    }()
    
}
