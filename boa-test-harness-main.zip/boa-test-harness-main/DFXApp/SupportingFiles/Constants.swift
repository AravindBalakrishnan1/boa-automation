//
//  Constants.swift
//  DFXApp
//
//  Created by Shobhit Agrawal on 05/09/22.
//

import Foundation

struct Constants {
    
    static let ProjectName = "DFX App"
    
    // Global
    static let Configuration = "Configuration"
    
    // Environments
    static let Development = "Devevlopment"
    static let Production = "Production"
    static let Staging = "Staging"
}
