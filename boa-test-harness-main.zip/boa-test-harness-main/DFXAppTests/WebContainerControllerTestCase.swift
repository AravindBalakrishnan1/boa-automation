//
//  WebContainerControllerTestCase.swift
//  DFXAppTests
//
//  Created by Anuj Dixit on 16/12/22.
//

import XCTest
@testable import DFXApp

final class WebContainerControllerTestCase: XCTestCase {
    
    func test_tryAgainAction_willWebViewOpen_true() {
        //Arrange
        let sut = getWebContainerController()
        sut.loadViewIfNeeded()
        
        // Action
        sut.tryAgainButton.sendActions(for: .touchUpInside)
        
        // Assert
        XCTAssertFalse(sut.willWebViewOpen)
    }

    private func getWebContainerController() -> WebContainerController {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "WebContainerController") as! WebContainerController
        return vc
    }

}
