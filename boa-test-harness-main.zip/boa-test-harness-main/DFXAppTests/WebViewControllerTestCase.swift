//
//  WebViewControllerTestCase.swift
//  DFXAppTests

import XCTest
import WebKit
@testable import DFXApp

final class WebViewControllerTestCase: XCTestCase {
    
    func test_baseUrl_match_with_webView_url() {
        // Arrangement
        let sut = getWebViewController()
        sut.viewModel = WebViewModelStub()
        
        // Action
        sut.loadViewIfNeeded()
        
        // Assert == Expectation
        XCTAssertEqual(sut.viewModel.baseURL, sut.webView.url?.absoluteString ?? "")
    }
    
    func test_webView_configuration_dataDetectorTypes_phoneNumber() {
        // Arrangement
        let sut = getWebViewController()
        sut.viewModel = StgWebViewModelStub()
        
        //Action
        sut.loadViewIfNeeded()
        
        let configuration = sut.webView.configuration
        //Assert
        XCTAssertEqual(configuration.dataDetectorTypes, .phoneNumber)
    }
    
    func test_webView_configuration_in_stg_env() {
        // Arrangement
        let sut = getWebViewController()
        sut.viewModel = StgWebViewModelStub()
        
        //Action
        sut.loadViewIfNeeded()
        
        let configuration = sut.webView.configuration
        XCTAssertTrue(configuration.preferences.value(forKey: "developerExtrasEnabled") as? Bool ?? false)
    }
    
    func test_webView_configuration_in_prod_env() {
        // Arrangement
        let sut = getWebViewController()
        sut.viewModel = ProdWebViewModelStub()
        
        //Action
        sut.loadViewIfNeeded()
        
        let configuration = sut.webView.configuration
        
        //Assert
        XCTAssertFalse(configuration.preferences.value(forKey: "developerExtrasEnabled") as? Bool ?? true)
    }
    
    func test_updateToolbar_CTA_isHidden() {
        let sut = getWebViewController()
        sut.loadViewIfNeeded()
        
        sut.updateToolBar()
        
        XCTAssertEqual(sut.backButton.isEnabled, sut.webView.canGoBack)
        XCTAssertEqual(sut.forwardButton.isEnabled, sut.webView.canGoForward)
    }
    
    private func getWebViewController() -> WebViewController {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "WebViewController") as! WebViewController
        return vc
    }
}

fileprivate class WebViewModelStub: WebViewModel {
    override var baseURL: String {
        return "www.xyz.com"
    }
}

fileprivate class StgWebViewModelStub: WebViewModelStub {
    override var isDevelopmentEnv: Bool {
        return true
    }
}

fileprivate class ProdWebViewModelStub: WebViewModelStub {
    override var isDevelopmentEnv: Bool {
        return false
    }
}
